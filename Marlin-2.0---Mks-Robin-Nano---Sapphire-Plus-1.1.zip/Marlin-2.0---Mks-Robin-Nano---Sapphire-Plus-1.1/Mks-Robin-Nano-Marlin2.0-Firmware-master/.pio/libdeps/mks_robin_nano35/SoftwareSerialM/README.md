# SoftwareSerialM
this lib aims at making a lib of software serial for cortex-M core MCUs.

Initially base on arduino LPC176x platform software serial code.
